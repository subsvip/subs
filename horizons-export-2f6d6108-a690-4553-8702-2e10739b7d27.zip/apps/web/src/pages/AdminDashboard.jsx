
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { LogOut, Plus, Edit2, Trash2, Save, X, ExternalLink, Sparkles } from 'lucide-react';
import { useAuth } from '@/components/AuthContext.jsx';
import { socialMediaPlatforms, getAllPlatforms } from '@/lib/socialMediaConfig.js';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';

const AdminDashboard = () => {
  const { logout, user } = useAuth();
  const navigate = useNavigate();
  
  const [tasks, setTasks] = useState([]);
  const [taskName, setTaskName] = useState('');
  const [taskLink, setTaskLink] = useState('');
  const [selectedPlatform, setSelectedPlatform] = useState('');
  const [formError, setFormError] = useState('');
  
  const [editingId, setEditingId] = useState(null);
  const [editName, setEditName] = useState('');
  const [editLink, setEditLink] = useState('');
  const [editPlatform, setEditPlatform] = useState('');

  useEffect(() => {
    const storedTasks = localStorage.getItem('tasks');
    if (storedTasks) {
      setTasks(JSON.parse(storedTasks));
    }
  }, []);

  const saveTasks = (updatedTasks) => {
    localStorage.setItem('tasks', JSON.stringify(updatedTasks));
    setTasks(updatedTasks);
  };

  const handleLogout = () => {
    logout();
    navigate('/login', { replace: true });
  };

  const validateUrl = (url) => {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  };

  const handleAddTask = (e) => {
    e.preventDefault();
    setFormError('');

    if (!taskName.trim()) {
      setFormError('Task name is required');
      return;
    }

    if (!taskLink.trim()) {
      setFormError('Social media link is required');
      return;
    }

    if (!validateUrl(taskLink)) {
      setFormError('Please enter a valid URL');
      return;
    }

    if (!selectedPlatform) {
      setFormError('Please select a platform');
      return;
    }

    const platformConfig = socialMediaPlatforms[selectedPlatform];
    const newTask = {
      id: Date.now().toString(),
      name: taskName.trim(),
      link: taskLink.trim(),
      platform: selectedPlatform,
      icon: platformConfig.icon,
      color: platformConfig.color,
      createdAt: new Date().toISOString()
    };

    const updatedTasks = [...tasks, newTask];
    saveTasks(updatedTasks);

    setTaskName('');
    setTaskLink('');
    setSelectedPlatform('');
  };

  const handleEditTask = (task) => {
    setEditingId(task.id);
    setEditName(task.name);
    setEditLink(task.link);
    setEditPlatform(task.platform);
  };

  const handleSaveEdit = (taskId) => {
    if (!editName.trim() || !editLink.trim() || !editPlatform) {
      return;
    }

    if (!validateUrl(editLink)) {
      return;
    }

    const platformConfig = socialMediaPlatforms[editPlatform];
    const updatedTasks = tasks.map(task =>
      task.id === taskId
        ? {
            ...task,
            name: editName.trim(),
            link: editLink.trim(),
            platform: editPlatform,
            icon: platformConfig.icon,
            color: platformConfig.color
          }
        : task
    );

    saveTasks(updatedTasks);
    setEditingId(null);
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditName('');
    setEditLink('');
    setEditPlatform('');
  };

  const handleDeleteTask = (taskId) => {
    const updatedTasks = tasks.filter(task => task.id !== taskId);
    saveTasks(updatedTasks);
  };

  return (
    <>
      <Helmet>
        <title>Admin dashboard - Gamification platform</title>
        <meta name="description" content="Manage gamification tasks and social media integrations" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
      </Helmet>

      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="bg-card border-b border-border sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Sparkles className="w-8 h-8 text-primary neon-glow" />
                <div>
                  <h1 className="text-2xl font-bold text-foreground" style={{ letterSpacing: '-0.02em' }}>
                    Admin dashboard
                  </h1>
                  <p className="text-sm text-muted-foreground">
                    Welcome back, {user?.username}
                  </p>
                </div>
              </div>
              <Button
                onClick={handleLogout}
                variant="destructive"
                className="transition-all duration-200 hover:brightness-110 active:scale-[0.98]"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </header>

        {/* Main content */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Task creation form */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="lg:col-span-1"
            >
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground">Create new task</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    Add a gamification task with social media link
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleAddTask} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="taskName" className="text-foreground font-medium">
                        Task name
                      </Label>
                      <Input
                        id="taskName"
                        type="text"
                        value={taskName}
                        onChange={(e) => setTaskName(e.target.value)}
                        placeholder="Subscribe to our channel"
                        className="auth-input text-foreground"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="platform" className="text-foreground font-medium">
                        Platform
                      </Label>
                      <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
                        <SelectTrigger className="auth-input text-foreground">
                          <SelectValue placeholder="Select platform" />
                        </SelectTrigger>
                        <SelectContent>
                          {getAllPlatforms().map((platform) => {
                            const config = socialMediaPlatforms[platform];
                            return (
                              <SelectItem key={platform} value={platform}>
                                <div className="flex items-center gap-2">
                                  <i className={`${config.icon} w-4`} style={{ color: config.color }}></i>
                                  <span>{config.name}</span>
                                </div>
                              </SelectItem>
                            );
                          })}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="taskLink" className="text-foreground font-medium">
                        Social media link
                      </Label>
                      <Input
                        id="taskLink"
                        type="url"
                        value={taskLink}
                        onChange={(e) => setTaskLink(e.target.value)}
                        placeholder={selectedPlatform ? socialMediaPlatforms[selectedPlatform]?.placeholder : 'https://...'}
                        className="auth-input text-foreground"
                      />
                    </div>

                    {formError && (
                      <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="error-message bg-destructive/10 border border-destructive/20 rounded-lg p-3"
                      >
                        {formError}
                      </motion.div>
                    )}

                    <Button
                      type="submit"
                      className="w-full auth-button"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add task
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </motion.div>

            {/* Task list */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="lg:col-span-2"
            >
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-foreground">Active tasks</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    {tasks.length} {tasks.length === 1 ? 'task' : 'tasks'} created
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {tasks.length === 0 ? (
                    <div className="text-center py-12">
                      <Sparkles className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
                      <h3 className="text-xl font-semibold text-foreground mb-2">
                        No tasks yet
                      </h3>
                      <p className="text-muted-foreground max-w-sm mx-auto">
                        Create your first gamification task to get started
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {tasks.map((task, index) => (
                        <motion.div
                          key={task.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.05 }}
                          className="task-card"
                        >
                          {editingId === task.id ? (
                            <div className="space-y-4">
                              <Input
                                value={editName}
                                onChange={(e) => setEditName(e.target.value)}
                                placeholder="Task name"
                                className="auth-input text-foreground"
                              />
                              <Select value={editPlatform} onValueChange={setEditPlatform}>
                                <SelectTrigger className="auth-input text-foreground">
                                  <SelectValue placeholder="Select platform" />
                                </SelectTrigger>
                                <SelectContent>
                                  {getAllPlatforms().map((platform) => {
                                    const config = socialMediaPlatforms[platform];
                                    return (
                                      <SelectItem key={platform} value={platform}>
                                        <div className="flex items-center gap-2">
                                          <i className={`${config.icon} w-4`} style={{ color: config.color }}></i>
                                          <span>{config.name}</span>
                                        </div>
                                      </SelectItem>
                                    );
                                  })}
                                </SelectContent>
                              </Select>
                              <Input
                                value={editLink}
                                onChange={(e) => setEditLink(e.target.value)}
                                placeholder="Social media link"
                                className="auth-input text-foreground"
                              />
                              <div className="flex gap-2">
                                <Button
                                  onClick={() => handleSaveEdit(task.id)}
                                  className="flex-1 bg-primary text-primary-foreground hover:brightness-110 active:scale-[0.98] transition-all duration-200"
                                >
                                  <Save className="w-4 h-4 mr-2" />
                                  Save
                                </Button>
                                <Button
                                  onClick={handleCancelEdit}
                                  variant="outline"
                                  className="flex-1 border-border text-foreground hover:bg-muted active:scale-[0.98] transition-all duration-200"
                                >
                                  <X className="w-4 h-4 mr-2" />
                                  Cancel
                                </Button>
                              </div>
                            </div>
                          ) : (
                            <div className="flex items-start justify-between gap-4">
                              <div className="flex items-start gap-4 flex-1 min-w-0">
                                <div className="flex-shrink-0 w-12 h-12 bg-muted rounded-xl flex items-center justify-center">
                                  <i className={`${task.icon} text-2xl`} style={{ color: task.color }}></i>
                                </div>
                                <div className="flex-1 min-w-0">
                                  <h3 className="text-lg font-semibold text-foreground mb-1">
                                    {task.name}
                                  </h3>
                                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                                    <span className="font-medium">{task.platform}</span>
                                    <span>•</span>
                                    <span>{new Date(task.createdAt).toLocaleDateString()}</span>
                                  </div>
                                  <a
                                    href={task.link}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="inline-flex items-center gap-1 text-sm text-primary hover:underline transition-all duration-200"
                                  >
                                    <span className="truncate max-w-xs">{task.link}</span>
                                    <ExternalLink className="w-3 h-3 flex-shrink-0" />
                                  </a>
                                </div>
                              </div>
                              <div className="flex gap-2 flex-shrink-0">
                                <Button
                                  onClick={() => handleEditTask(task)}
                                  variant="outline"
                                  size="sm"
                                  className="border-border text-foreground hover:bg-muted active:scale-[0.98] transition-all duration-200"
                                >
                                  <Edit2 className="w-4 h-4" />
                                </Button>
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      className="border-destructive/50 text-destructive hover:bg-destructive/10 active:scale-[0.98] transition-all duration-200"
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </Button>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Delete task</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        Are you sure you want to delete "{task.name}"? This action cannot be undone.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                                      <AlertDialogAction
                                        onClick={() => handleDeleteTask(task.id)}
                                        className="bg-destructive text-destructive-foreground hover:brightness-110"
                                      >
                                        Delete
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </div>
                            </div>
                          )}
                        </motion.div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </main>
      </div>
    </>
  );
};

export default AdminDashboard;
